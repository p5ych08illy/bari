﻿namespace Bari.Core.Model
{
    public enum ReferenceType
    {
        Build,
        Runtime
    }
}