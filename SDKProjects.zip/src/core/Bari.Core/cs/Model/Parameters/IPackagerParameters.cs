﻿namespace Bari.Core.Model.Parameters
{    
    public interface IPackagerParameters: IProjectParameters
    {         
    }
}