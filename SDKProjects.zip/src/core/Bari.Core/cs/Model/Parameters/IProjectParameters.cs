﻿namespace Bari.Core.Model.Parameters
{
    /// <summary>
    /// Represents a custom project parameter block, which can be assigned to project, module or a full suite
    /// </summary>
    public interface IProjectParameters
    {         
    }
}