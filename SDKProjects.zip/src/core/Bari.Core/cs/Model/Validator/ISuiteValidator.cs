﻿namespace Bari.Core.Model.Validator
{
    public interface ISuiteValidator
    {
        void Validate(Suite suite);
    }
}