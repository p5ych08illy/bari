namespace Bari.Plugins.CodeContracts.Model
{
    /// <summary>
    /// Contract reference modes
    /// </summary>
    public enum ContractReferenceMode
    {
        None,
        Build,
        DoNotBuild
    }
}