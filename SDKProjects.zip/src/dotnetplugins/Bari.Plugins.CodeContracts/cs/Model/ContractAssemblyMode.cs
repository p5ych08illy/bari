namespace Bari.Plugins.CodeContracts.Model
{
    /// <summary>
    /// Contract verification mode
    /// </summary>
    public enum ContractAssemblyMode
    {
        CustomParameterVerification,
        StandardContractRequires
    }
}