﻿namespace Bari.Plugins.VsCore.Model
{
    public enum FrameworkVersion
    {
        v20,
        v30,
        v35,
        v4,
        v45,
        v451,
        v452,
        v46,
        v461,
        v462,
        v47,
        v471,
        v472,
        v48,
    }
}