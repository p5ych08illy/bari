﻿namespace Bari.Plugins.VsCore.Model
{
    public enum FrameworkProfile
    {
        Default,
        Client
    }
}