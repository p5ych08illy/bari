﻿namespace Bari.Plugins.VsCore.Model
{
    public enum CLRPlatform
    {
        AnyCPU,
        AnyCPU32BitPreferred,
        ARM,
        x64,
        x86,
        Itanium
    }
}