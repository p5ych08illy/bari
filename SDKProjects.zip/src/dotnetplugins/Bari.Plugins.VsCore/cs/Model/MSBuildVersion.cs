﻿namespace Bari.Plugins.VsCore.Model
{
    public enum MSBuildVersion
    {
        Net40x86,
        Net40x64,
        VS2013,
        VS2015,
        VS2017,
        VS2019,
        VS2022,
        Default
    }
}