﻿namespace Bari.Plugins.VsCore.Model
{
    public enum DebugLevel
    {
        None,
        PdbOnly,
        Full
    }
}