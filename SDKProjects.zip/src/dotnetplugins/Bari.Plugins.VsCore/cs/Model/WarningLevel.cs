﻿namespace Bari.Plugins.VsCore.Model
{
    public enum WarningLevel
    {
        Off,
        Level1,
        Level2,
        Level3,
        All
    }
}