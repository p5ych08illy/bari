﻿namespace Bari.Plugins.VCpp.Model
{
    public enum CLRImageType
    {
        Default,
        ForceIJWImage,
        ForcePureILImage,
        ForceSafeILImage
    }
}