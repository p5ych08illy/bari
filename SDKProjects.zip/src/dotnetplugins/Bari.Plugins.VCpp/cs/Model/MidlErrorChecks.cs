﻿namespace Bari.Plugins.VCpp.Model
{
    public enum MidlErrorChecks
    {
        None,
        Custom,
        All
    }
}