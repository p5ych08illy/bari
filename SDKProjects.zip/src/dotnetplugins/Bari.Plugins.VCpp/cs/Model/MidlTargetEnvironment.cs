﻿namespace Bari.Plugins.VCpp.Model
{
    public enum MidlTargetEnvironment
    {
        NotSet,
        Win32,
        Itanium,
        X64
    }
}