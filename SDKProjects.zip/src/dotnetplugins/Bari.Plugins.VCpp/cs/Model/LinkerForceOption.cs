﻿namespace Bari.Plugins.VCpp.Model
{
    public enum LinkerForceOption
    {
        Disabled,
        Enabled,
        MultiplyDefinedSymbolOnly,
        UndefinedSymbolOnly
    }
}