﻿namespace Bari.Plugins.VCpp.Model
{
    public enum UACExecutionLevel
    {
        AsInvoker,
        HighestAvailable,
        RequireAdministrator
    }
}