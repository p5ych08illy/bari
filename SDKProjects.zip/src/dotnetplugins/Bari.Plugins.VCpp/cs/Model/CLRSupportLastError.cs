﻿namespace Bari.Plugins.VCpp.Model
{
    public enum CLRSupportLastError
    {
        Enabled,
        Disabled,
        SystemDLLs
    }
}