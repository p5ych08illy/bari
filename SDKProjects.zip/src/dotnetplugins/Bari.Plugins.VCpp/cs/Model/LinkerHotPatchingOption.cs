﻿namespace Bari.Plugins.VCpp.Model
{
    public enum LinkerHotPatchingOption
    {
        Disabled,
        Enabled,
        X86Image,
        X64Image,
        ItaniumImage
    }
}