﻿namespace Bari.Plugins.VCpp.Model
{
    public enum UseOfATL
    {
        None,
        Static,
        Dynamic
    }
}