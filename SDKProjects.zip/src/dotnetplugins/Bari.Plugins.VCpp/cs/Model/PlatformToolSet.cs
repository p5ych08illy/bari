﻿using System;

namespace Bari.Plugins.VCpp.Model
{
    public enum PlatformToolSet
    {
        VS2012,
        VS2013,
        VS2015,
        VS2017,
        VS2019,
    }
}

