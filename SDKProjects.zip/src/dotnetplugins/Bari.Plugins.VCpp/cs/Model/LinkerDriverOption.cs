﻿namespace Bari.Plugins.VCpp.Model
{
    public enum LinkerDriverOption
    {
        NotSet,
        Driver,
        UpOnly,
        WDM
    }
}