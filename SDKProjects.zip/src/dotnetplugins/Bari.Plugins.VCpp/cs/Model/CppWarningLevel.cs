﻿namespace Bari.Plugins.VCpp.Model
{
    public enum CppWarningLevel
    {
        Off,
        Level1,
        Level2,
        Level3,
        Level4,
        All
    }
}