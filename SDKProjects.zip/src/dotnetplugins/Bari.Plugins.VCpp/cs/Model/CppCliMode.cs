﻿namespace Bari.Plugins.VCpp.Model
{
    public enum CppCliMode
    {
        Disabled,
        Enabled,
        Pure,
        Safe,
        OldSyntax
    }
}