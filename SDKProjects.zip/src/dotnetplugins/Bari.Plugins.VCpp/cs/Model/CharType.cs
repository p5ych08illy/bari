﻿namespace Bari.Plugins.VCpp.Model
{
    public enum CharType
    {
        Signed,
        Unsigned,
        Ascii
    }
}