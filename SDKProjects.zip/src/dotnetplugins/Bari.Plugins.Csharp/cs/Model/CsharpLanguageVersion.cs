﻿namespace Bari.Plugins.Csharp.Model
{
    public enum CsharpLanguageVersion
    {
        Default,
        ISO1,
        ISO2,
        V3,
        V4,
        V5,
        V6,
        V7,
        V71,
        V72,
        V73,
        V8,
    }
}