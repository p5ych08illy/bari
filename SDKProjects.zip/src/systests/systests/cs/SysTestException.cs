using System;


namespace systests
{
	class SysTestException : Exception
	{
        public SysTestException (string message) : base(message)
        {
        }        
	}

}

