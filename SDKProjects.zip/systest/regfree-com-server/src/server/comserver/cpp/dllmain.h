// dllmain.h : Declaration of module class.

