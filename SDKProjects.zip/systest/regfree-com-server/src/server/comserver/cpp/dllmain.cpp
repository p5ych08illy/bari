// dllmain.cpp : Implementation of DllMain.

#include "stdafx.h"
#include "resource.h"
#include "dllmain.h"

[module(dll, uuid="{FD0C08E8-AFCE-4915-A2E8-B09EC9DCE463}",
		name="comserver",
		resource_name="IDR_REGFREECOMSERVER")]
class CRegFreeComServerModule 
{
};
