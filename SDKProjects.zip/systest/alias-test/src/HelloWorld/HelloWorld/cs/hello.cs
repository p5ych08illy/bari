public static class Hello
{
	public static int Main(string[] args) 
	{
		System.Console.WriteLine(dep.TestClass.Message);

		return 9;
	}
}