namespace OtherModule.Dep
{
	public class dep 
	{
		public static readonly string Prop = "TEST";
	}
}