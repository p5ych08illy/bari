namespace Proj12
{
	public class dep 
	{
		public static readonly string Prop = "2";
	}
}