namespace Proj22
{
	public class dep 
	{
		public static readonly string Prop = "4";
	}
}