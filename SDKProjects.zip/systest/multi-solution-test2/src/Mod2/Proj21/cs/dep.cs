namespace Proj21
{
	public class dep 
	{
		public static readonly string Prop = Proj12.dep.Prop + "3";
	}
}