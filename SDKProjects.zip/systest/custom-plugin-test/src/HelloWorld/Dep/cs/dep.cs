namespace HelloWorld.Dep
{
	public class dep 
	{
		public static readonly string Prop = "TEST";
	}
}