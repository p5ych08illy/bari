#include "stdafx.h"

std::wstring get_message()
{
	return std::wstring(L"Hello world!");
}