#pragma once

#include <iostream>

std::wstring get_message();