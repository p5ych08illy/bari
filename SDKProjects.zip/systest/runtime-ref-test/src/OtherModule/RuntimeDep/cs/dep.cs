namespace OtherModule.RuntimeDep
{
	public class dep 
	{
		public static readonly string Prop = "TEST";
	}
}