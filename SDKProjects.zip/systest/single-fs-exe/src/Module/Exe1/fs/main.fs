﻿namespace Exe1
module Main = 
    [<EntryPoint>]
    let main args =
        printfn "Test F# executable running"    
        12
