public static class Hello
{
	public static int Main(string[] args) 
	{
		System.Console.WriteLine("Test executable running");

		return 11;
	}
}